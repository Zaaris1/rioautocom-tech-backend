import uuid, json
from datetime import datetime
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, Query, Body, File, Form, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from app.database import get_db
from app.models import (
    Ticket, TicketUpdate, TicketClosure, TicketAttachment,
    Store, Network, ClientAccess, ClientNetworkAccess, User,
    ROLE_ADMIN, ROLE_TECH, ROLE_CLIENT
)
from app.schemas import (
    TicketCreate, TicketOut, TicketDetail,
    AssignRequest, CommentRequest, CloseRequest, StatusRequest, TicketUpdateOut,
    EditClosureRequest, TicketAttachmentOut,  # ✅ NOVO (opção 2)
)
from app.deps import get_current_user
from app.drive_storage import upload_ticket_file

router = APIRouter()

VALID_STATUSES = {"ABERTO","ATRIBUIDO","EM_ATENDIMENTO","PENDENTE","CONCLUIDO","CANCELADO"}
VALID_PRIORITIES = {"NORMAL", "URGENTE"}

# ✅ alinhado ao Enum do schemas.py e ao frontend
VALID_TYPES = {"REPARO", "SUPORTE", "VISITA", "MANUTENCAO"}


ALLOWED_IMAGE_MIME = {"image/jpeg", "image/png", "image/webp"}
ALLOWED_VIDEO_MIME = {"video/mp4", "video/quicktime", "video/webm"}
ALLOWED_EXT = {".jpg", ".jpeg", ".png", ".webp", ".mp4", ".mov", ".webm"}


def _env_int(name: str, default: int) -> int:
    try:
        return int(str(__import__("os").getenv(name, default)).strip())
    except Exception:
        return default


def max_image_bytes() -> int:
    return _env_int("MAX_IMAGE_MB", 10) * 1024 * 1024


def max_video_bytes() -> int:
    return _env_int("MAX_VIDEO_MB", 80) * 1024 * 1024


def max_attachments_per_phase() -> int:
    return _env_int("MAX_ATTACHMENTS_PER_PHASE", 5)


def _clean_drive_folder_part(value: Optional[str], fallback: str) -> str:
    raw = str(value or "").strip() or fallback
    import re
    raw = re.sub(r"[\\/:*?\"<>|]+", "-", raw)
    raw = re.sub(r"\s+", " ", raw).strip()
    return raw[:80] or fallback


def ticket_drive_folder_name(db: Session, ticket: Ticket) -> str:
    store = db.query(Store).filter(Store.id == ticket.store_id).first()

    store_name = _clean_drive_folder_part(store.name if store else None, "Loja")
    network_name = None
    if store and store.network_id:
        network = db.query(Network).filter(Network.id == store.network_id).first()
        if network:
            network_name = _clean_drive_folder_part(network.name, "Rede")

    opened = ticket.opened_at or datetime.utcnow()
    date_part = opened.strftime("%d-%m-%Y")

    # O backend usa UUID internamente. Usamos apenas um identificador curto no final
    # para evitar misturar anexos caso a mesma loja tenha mais de um chamado no mesmo dia.
    short_id = str(ticket.id or "")[:8].upper() or "SEM-ID"

    if network_name:
        return f"{network_name} - {store_name} - {date_part} - Chamado {short_id}"

    return f"{store_name} - {date_part} - Chamado {short_id}"


def normalize_phase(value: str) -> str:
    phase = str(value or "").strip().upper()
    if phase in ("ABERTURA", "OPENING", "CREATE"):
        return "ABERTURA"
    if phase in ("FECHAMENTO", "CLOSING", "CLOSE"):
        return "FECHAMENTO"
    raise HTTPException(status_code=400, detail="Fase de anexo inválida")


def attachment_out(a: TicketAttachment) -> TicketAttachmentOut:
    return TicketAttachmentOut(
        id=a.id,
        ticket_id=a.ticket_id,
        phase=a.phase,
        original_filename=a.original_filename,
        mime_type=a.mime_type,
        size_bytes=a.size_bytes,
        drive_file_id=a.drive_file_id,
        drive_view_link=a.drive_view_link,
        drive_download_link=a.drive_download_link,
        created_at=a.created_at.isoformat() if a.created_at else None,
    )


def _file_ext(filename: str) -> str:
    import os
    return os.path.splitext(str(filename or ""))[1].lower()


def validate_upload_file(file: UploadFile, data: bytes) -> None:
    filename = file.filename or "arquivo"
    mime = (file.content_type or "application/octet-stream").lower()
    ext = _file_ext(filename)

    if ext not in ALLOWED_EXT:
        raise HTTPException(status_code=400, detail=f"Tipo de arquivo não permitido: {filename}")

    size = len(data or b"")
    if size <= 0:
        raise HTTPException(status_code=400, detail=f"Arquivo vazio: {filename}")

    is_image = mime in ALLOWED_IMAGE_MIME or ext in {".jpg", ".jpeg", ".png", ".webp"}
    is_video = mime in ALLOWED_VIDEO_MIME or ext in {".mp4", ".mov", ".webm"}

    if not is_image and not is_video:
        raise HTTPException(status_code=400, detail=f"Formato inválido: {filename}")

    if is_image and size > max_image_bytes():
        raise HTTPException(status_code=400, detail=f"Imagem acima do limite de {max_image_bytes() // 1024 // 1024} MB: {filename}")

    if is_video and size > max_video_bytes():
        raise HTTPException(status_code=400, detail=f"Vídeo acima do limite de {max_video_bytes() // 1024 // 1024} MB: {filename}")


def save_ticket_attachments(
    *,
    db: Session,
    ticket: Ticket,
    user: User,
    phase: str,
    files: Optional[List[UploadFile]],
) -> List[TicketAttachment]:
    phase = normalize_phase(phase)
    clean_files = [f for f in (files or []) if f and f.filename]
    if not clean_files:
        return []

    current_count = db.query(TicketAttachment).filter(
        TicketAttachment.ticket_id == ticket.id,
        TicketAttachment.phase == phase,
    ).count()

    if current_count + len(clean_files) > max_attachments_per_phase():
        raise HTTPException(
            status_code=400,
            detail=f"Limite de {max_attachments_per_phase()} anexos por fase do chamado excedido",
        )

    created: List[TicketAttachment] = []
    for file in clean_files:
        data = file.file.read()
        validate_upload_file(file, data)

        mime = (file.content_type or "application/octet-stream").lower()
        drive = upload_ticket_file(
            ticket_id=ticket.id,
            ticket_folder_name=ticket_drive_folder_name(db, ticket),
            phase=phase,
            filename=file.filename or "arquivo",
            mime_type=mime,
            data=data,
        )

        attachment = TicketAttachment(
            id=str(uuid.uuid4()),
            ticket_id=ticket.id,
            phase=phase,
            original_filename=file.filename or "arquivo",
            mime_type=mime,
            size_bytes=len(data),
            drive_file_id=drive["drive_file_id"],
            drive_view_link=drive.get("drive_view_link"),
            drive_download_link=drive.get("drive_download_link"),
            uploaded_by_user_id=user.id,
        )
        db.add(attachment)
        created.append(attachment)

    if created:
        add_update(
            db,
            ticket.id,
            user.id,
            "ATTACHMENT",
            note=f"{len(created)} anexo(s) enviado(s) na {'abertura' if phase == 'ABERTURA' else 'conclusão'}",
            payload={"phase": phase, "count": len(created)},
        )

    return created


def make_ticket_out(t: Ticket, store_name: Optional[str] = None) -> TicketOut:
    return TicketOut(
        id=t.id, store_id=t.store_id, store_name=store_name, status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
    )


def add_update(
    db: Session,
    ticket_id: str,
    user_id: str,
    event_type: str,
    note: Optional[str] = None,
    payload: Optional[dict] = None
):
    db.add(TicketUpdate(
        id=str(uuid.uuid4()),
        ticket_id=ticket_id,
        created_by_user_id=user_id,
        event_type=event_type,
        note=note,
        payload_json=json.dumps(payload or {}, ensure_ascii=False),
    ))


def ensure_store_access_for_client(db: Session, user: User, store_id: str):
    """
    ✅ CLIENT tem acesso se:
    - vínculo direto em client_access
    OU
    - vínculo por rede em client_network_access (rede da loja)
    """
    ok = (
        db.query(Store)
        .outerjoin(
            ClientAccess,
            (ClientAccess.store_id == Store.id) & (ClientAccess.user_id == user.id),
        )
        .outerjoin(
            ClientNetworkAccess,
            (ClientNetworkAccess.network_id == Store.network_id) & (ClientNetworkAccess.user_id == user.id),
        )
        .filter(Store.id == store_id)
        .filter(
            or_(
                ClientAccess.user_id.isnot(None),
                ClientNetworkAccess.user_id.isnot(None),
            )
        )
        .first()
    )

    if not ok:
        raise HTTPException(status_code=403, detail="Sem permissão para esta loja")


def ensure_can_view_ticket(db: Session, user: User, ticket: Ticket) -> None:
    if user.role in (ROLE_ADMIN, ROLE_TECH):
        return
    ensure_store_access_for_client(db, user, ticket.store_id)


def ensure_assigned_to_user(ticket: Ticket, user: User):
    if ticket.assigned_tech_id != user.id:
        raise HTTPException(status_code=403, detail="Chamado não atribuído a você")


class TicketEditRequest(BaseModel):
    requester_name: Optional[str] = Field(default=None, max_length=120)
    local: Optional[str] = Field(default=None, max_length=500)
    problem: Optional[str] = Field(default=None, max_length=5000)
    priority: Optional[str] = Field(default=None)
    type: Optional[str] = Field(default=None)

    class Config:
        extra = "forbid"


class ReopenTicketRequest(BaseModel):
    delete_closing_attachments: bool = Field(
        default=False,
        description="Se true, remove também os anexos enviados na fase de fechamento.",
    )

    class Config:
        extra = "forbid"


def _norm_str(v: Optional[str]) -> Optional[str]:
    if v is None:
        return None
    s = str(v).strip()
    return s if s else None


# ---------- Create (ADMIN only) ----------
@router.post("/", response_model=TicketOut)
def create_ticket(
    body: TicketCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    if user.role != ROLE_ADMIN:
        raise HTTPException(status_code=403, detail="Apenas admin cria chamado")

    store = db.query(Store).filter(Store.id == body.store_id, Store.active == True).first()
    if not store:
        raise HTTPException(status_code=404, detail="Loja não encontrada/ativa")

    ticket_type = body.type.value if hasattr(body.type, "value") else body.type
    ticket_priority = body.priority.value if hasattr(body.priority, "value") else body.priority

    t = Ticket(
        id=str(uuid.uuid4()),
        store_id=body.store_id,
        opened_by_admin_id=user.id,
        requester_name=body.requester_name,
        local=body.local,
        problem=body.problem,
        type=ticket_type,
        priority=ticket_priority,
        status="ABERTO",
        opened_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    db.add(t)
    db.commit()

    add_update(db, t.id, user.id, "CREATE", note="Chamado criado", payload={"status": "ABERTO"})
    db.commit()

    return TicketOut(
        id=t.id, store_id=t.store_id, store_name=store.name, status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
    )


# ---------- Create with attachments (ADMIN only) ----------
@router.post("/with-attachments", response_model=TicketOut)
def create_ticket_with_attachments(
    store_id: str = Form(...),
    requester_name: Optional[str] = Form(None),
    local: Optional[str] = Form(None),
    problem: str = Form(...),
    type: str = Form(...),
    priority: str = Form(...),
    files: Optional[List[UploadFile]] = File(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.role != ROLE_ADMIN:
        raise HTTPException(status_code=403, detail="Apenas admin cria chamado")

    store = db.query(Store).filter(Store.id == store_id, Store.active == True).first()
    if not store:
        raise HTTPException(status_code=404, detail="Loja não encontrada/ativa")

    if type not in VALID_TYPES:
        raise HTTPException(status_code=400, detail="Tipo de chamado inválido")
    if priority not in VALID_PRIORITIES:
        raise HTTPException(status_code=400, detail="Prioridade inválida")

    clean_problem = (problem or "").strip()
    if len(clean_problem) < 5:
        raise HTTPException(status_code=400, detail="Descreva o problema com pelo menos 5 caracteres")

    t = Ticket(
        id=str(uuid.uuid4()),
        store_id=store_id,
        opened_by_admin_id=user.id,
        requester_name=(requester_name or "").strip() or None,
        local=(local or "").strip() or None,
        problem=clean_problem,
        type=type,
        priority=priority,
        status="ABERTO",
        opened_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    db.add(t)
    add_update(db, t.id, user.id, "CREATE", note="Chamado criado", payload={"status": "ABERTO"})
    save_ticket_attachments(db=db, ticket=t, user=user, phase="ABERTURA", files=files)
    db.commit()

    return make_ticket_out(t, store.name)


# ---------- Attachments ----------
@router.get("/{ticket_id}/attachments", response_model=list[TicketAttachmentOut])
def list_ticket_attachments(
    ticket_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")
    ensure_can_view_ticket(db, user, t)

    rows = db.query(TicketAttachment).filter(
        TicketAttachment.ticket_id == ticket_id
    ).order_by(TicketAttachment.created_at.asc()).all()
    return [attachment_out(a) for a in rows]


@router.post("/{ticket_id}/attachments", response_model=list[TicketAttachmentOut])
def upload_ticket_attachments(
    ticket_id: str,
    phase: str = Form(...),
    files: Optional[List[UploadFile]] = File(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    phase_norm = normalize_phase(phase)

    if phase_norm == "ABERTURA":
        if user.role != ROLE_ADMIN:
            raise HTTPException(status_code=403, detail="Apenas admin anexa arquivos na abertura")
    else:
        if user.role not in (ROLE_TECH, ROLE_ADMIN):
            raise HTTPException(status_code=403, detail="Apenas técnico/admin anexa arquivos no fechamento")
        if user.role == ROLE_TECH:
            ensure_assigned_to_user(t, user)

    created = save_ticket_attachments(db=db, ticket=t, user=user, phase=phase_norm, files=files)
    t.updated_at = datetime.utcnow()
    db.add(t)
    db.commit()

    return [attachment_out(a) for a in created]


# ---------- List (by role + filters) ----------
@router.get("/", response_model=list[TicketOut])
def list_tickets(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
    open_only: bool = Query(False, description="Somente ABERTO e sem técnico (fila)"),
    mine_only: bool = Query(False, description="Somente tickets do técnico logado"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    network_id: Optional[str] = Query(None, description="Filtrar por rede (network_id)"),
    store_id: Optional[str] = Query(None, description="Filtrar por loja (store_id)"),
    limit: int = Query(200, ge=1, le=500),
):
    if status and status not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="status inválido")

    q = (
        db.query(
            Ticket,
            Store.name,
            TicketClosure.resolution_text,
            User.username,
        )
        .join(Store, Store.id == Ticket.store_id)
        .outerjoin(TicketClosure, TicketClosure.ticket_id == Ticket.id)
        .outerjoin(User, User.id == Ticket.assigned_tech_id)
    )

    if store_id:
        q = q.filter(Ticket.store_id == store_id)
    elif network_id:
        q = q.filter(Store.network_id == network_id)

    if user.role == ROLE_CLIENT:
        q = (
            q.outerjoin(
                ClientAccess,
                (ClientAccess.store_id == Ticket.store_id) & (ClientAccess.user_id == user.id),
            )
            .outerjoin(
                ClientNetworkAccess,
                (ClientNetworkAccess.network_id == Store.network_id) & (ClientNetworkAccess.user_id == user.id),
            )
            .filter(
                or_(
                    ClientAccess.user_id.isnot(None),
                    ClientNetworkAccess.user_id.isnot(None),
                )
            )
        )

    if user.role == ROLE_TECH:
        if open_only:
            q = q.filter(Ticket.status == "ABERTO", Ticket.assigned_tech_id.is_(None))
        elif mine_only:
            q = q.filter(Ticket.assigned_tech_id == user.id)
        else:
            q = q.filter(
                (and_(Ticket.status == "ABERTO", Ticket.assigned_tech_id.is_(None))) |
                (Ticket.assigned_tech_id == user.id)
            )

    if status:
        q = q.filter(Ticket.status == status)

    rows = q.order_by(Ticket.opened_at.desc()).limit(limit).all()

    return [
        TicketOut(
            id=t.id, store_id=t.store_id, store_name=store_name, status=t.status,
            problem=t.problem, type=t.type, priority=t.priority,
            requester_name=t.requester_name, local=t.local,
            assigned_tech_id=t.assigned_tech_id,
            assigned_to=assigned_to,
            opened_at=t.opened_at.isoformat() if t.opened_at else None,
            updated_at=t.updated_at.isoformat() if t.updated_at else None,
            resolution_text=resolution_text,
        )
        for (t, store_name, resolution_text, assigned_to) in rows
    ]


# ---------- Get detail (devolve {ticket, updates}) ----------
@router.get("/{ticket_id}")
def get_ticket(
    ticket_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    ensure_can_view_ticket(db, user, t)

    store = db.query(Store).filter(Store.id == t.store_id).first()
    closure = db.query(TicketClosure).filter(TicketClosure.ticket_id == t.id).first()

    ticket = TicketDetail(
        id=t.id, store_id=t.store_id, store_name=(store.name if store else None), status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        assigned_to=(
            db.query(User.username).filter(User.id == t.assigned_tech_id).scalar()
            if t.assigned_tech_id else None
        ),
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
        resolution_text=closure.resolution_text if closure else None,
    )

    rows = db.query(TicketUpdate).filter(
        TicketUpdate.ticket_id == ticket_id
    ).order_by(TicketUpdate.created_at.asc()).all()

    updates = [
        TicketUpdateOut(
            id=u.id,
            ticket_id=u.ticket_id,
            created_by_user_id=u.created_by_user_id,
            created_at=u.created_at.isoformat() if u.created_at else "",
            event_type=u.event_type,
            note=u.note,
            payload_json=u.payload_json,
        )
        for u in rows
    ]

    attachments_rows = db.query(TicketAttachment).filter(
        TicketAttachment.ticket_id == ticket_id
    ).order_by(TicketAttachment.created_at.asc()).all()

    attachments = [attachment_out(a) for a in attachments_rows]

    return {"ticket": ticket, "updates": updates, "attachments": attachments}


# ---------- Edit ticket (ADMIN only) ----------
@router.patch("/{ticket_id}", response_model=TicketOut)
def edit_ticket(
    ticket_id: str,
    body: TicketEditRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    if user.role != ROLE_ADMIN:
        raise HTTPException(status_code=403, detail="Apenas admin pode editar chamado")

    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    store = db.query(Store).filter(Store.id == t.store_id).first()
    store_name = store.name if store else None

    before = {
        "requester_name": t.requester_name,
        "local": t.local,
        "problem": t.problem,
        "priority": t.priority,
        "type": t.type,
    }

    changed = {}

    if body.requester_name is not None:
        v = _norm_str(body.requester_name)
        if v is None:
            raise HTTPException(status_code=400, detail="requester_name não pode ser vazio")
        if v != t.requester_name:
            t.requester_name = v
            changed["requester_name"] = v

    if body.local is not None:
        v = _norm_str(body.local)
        if v is None:
            raise HTTPException(status_code=400, detail="local não pode ser vazio")
        if v != t.local:
            t.local = v
            changed["local"] = v

    if body.problem is not None:
        v = _norm_str(body.problem)
        if v is None:
            raise HTTPException(status_code=400, detail="problem não pode ser vazio")
        if v != t.problem:
            t.problem = v
            changed["problem"] = v

    if body.priority is not None:
        v = _norm_str(body.priority)
        if v is None:
            raise HTTPException(status_code=400, detail="priority não pode ser vazio")
        if v not in VALID_PRIORITIES:
            raise HTTPException(status_code=400, detail="priority inválida")
        if v != t.priority:
            t.priority = v
            changed["priority"] = v

    if body.type is not None:
        v = _norm_str(body.type)
        if v is None:
            raise HTTPException(status_code=400, detail="type não pode ser vazio")
        if v not in VALID_TYPES:
            raise HTTPException(status_code=400, detail="type inválido")
        if v != t.type:
            t.type = v
            changed["type"] = v

    if not changed:
        raise HTTPException(status_code=400, detail="Nenhuma alteração enviada")

    t.updated_at = datetime.utcnow()
    db.add(t)

    after = {
        "requester_name": t.requester_name,
        "local": t.local,
        "problem": t.problem,
        "priority": t.priority,
        "type": t.type,
    }

    add_update(
        db,
        t.id,
        user.id,
        "EDIT",
        note="Chamado editado",
        payload={"changed": changed, "before": before, "after": after}
    )
    db.commit()

    return TicketOut(
        id=t.id, store_id=t.store_id, store_name=store_name, status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
    )


# ---------- Reopen (ADMIN only) ----------
@router.post("/{ticket_id}/reopen", response_model=TicketOut)
def reopen_ticket(
    ticket_id: str,
    body: Optional[ReopenTicketRequest] = Body(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.role != ROLE_ADMIN:
        raise HTTPException(status_code=403, detail="Apenas admin pode reabrir chamado")

    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    if t.status != "CONCLUIDO":
        raise HTTPException(status_code=409, detail="Somente chamados CONCLUÍDOS podem ser reabertos")

    store = db.query(Store).filter(Store.id == t.store_id).first()
    closure = db.query(TicketClosure).filter(TicketClosure.ticket_id == t.id).first()
    delete_closing_attachments = bool(body.delete_closing_attachments) if body else False

    old_status = t.status
    previous_payload = {
        "previous_status": t.status,
        "new_status": "ABERTO",
        "previous_assigned_tech_id": t.assigned_tech_id,
        "previous_assigned_at": t.assigned_at.isoformat() if t.assigned_at else None,
        "previous_started_at": t.started_at.isoformat() if t.started_at else None,
        "previous_closed_at": t.closed_at.isoformat() if t.closed_at else None,
        "previous_resolution_text": closure.resolution_text if closure else None,
        "previous_closed_by_user_id": closure.closed_by_user_id if closure else None,
        "previous_closure_closed_at": closure.closed_at.isoformat() if closure and closure.closed_at else None,
        "delete_closing_attachments": delete_closing_attachments,
        "deleted_closing_attachments_count": 0,
    }

    if delete_closing_attachments:
        closing_attachments = db.query(TicketAttachment).filter(
            TicketAttachment.ticket_id == t.id,
            TicketAttachment.phase == "FECHAMENTO",
        ).all()
        previous_payload["deleted_closing_attachments_count"] = len(closing_attachments)
        for attachment in closing_attachments:
            db.delete(attachment)

    if closure:
        db.delete(closure)

    t.status = "ABERTO"
    t.assigned_tech_id = None
    t.assigned_at = None
    t.started_at = None
    t.closed_at = None
    t.updated_at = datetime.utcnow()

    db.add(t)

    add_update(
        db,
        t.id,
        user.id,
        "REOPEN",
        note="Chamado reaberto pelo admin e devolvido para a fila geral.",
        payload=previous_payload,
    )
    add_update(
        db,
        t.id,
        user.id,
        "STATUS_CHANGE",
        note="Chamado reaberto",
        payload={"from": old_status, "to": "ABERTO"},
    )

    db.commit()
    db.refresh(t)

    return make_ticket_out(t, store.name if store else None)


# ---------- Updates ----------
@router.get("/{ticket_id}/updates", response_model=list[TicketUpdateOut])
def list_updates(
    ticket_id: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    ensure_can_view_ticket(db, user, t)

    rows = db.query(TicketUpdate).filter(
        TicketUpdate.ticket_id == ticket_id
    ).order_by(TicketUpdate.created_at.asc()).all()

    return [
        TicketUpdateOut(
            id=u.id,
            ticket_id=u.ticket_id,
            created_by_user_id=u.created_by_user_id,
            created_at=u.created_at.isoformat() if u.created_at else "",
            event_type=u.event_type,
            note=u.note,
            payload_json=u.payload_json,
        )
        for u in rows
    ]


# ---------- Assign ----------
@router.post("/{ticket_id}/assign", response_model=TicketOut)
def assign_ticket(
    ticket_id: str,
    body: Optional[AssignRequest] = Body(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    if user.role == ROLE_CLIENT:
        raise HTTPException(status_code=403, detail="Cliente não pode atribuir chamado")

    store = db.query(Store).filter(Store.id == t.store_id).first()
    store_name = store.name if store else None

    old_status = t.status

    if user.role == ROLE_ADMIN:
        username = (body.username if body else None)

        if username:
            tech = db.query(User).filter(
                User.username == username,
                User.role == ROLE_TECH,
                User.active == True
            ).first()
            if not tech:
                raise HTTPException(status_code=404, detail="Técnico não encontrado/ativo")

            t.assigned_tech_id = tech.id
            if t.status == "ABERTO":
                t.status = "ATRIBUIDO"
            t.assigned_at = datetime.utcnow()
            t.updated_at = datetime.utcnow()

            db.add(t)

            add_update(
                db, t.id, user.id, "ASSIGN",
                note="Atribuído pelo admin",
                payload={"username": tech.username, "tech_id": tech.id}
            )
            if old_status != t.status:
                add_update(db, t.id, user.id, "STATUS_CHANGE", payload={"from": old_status, "to": t.status})

            db.commit()

        else:
            if t.assigned_tech_id and t.assigned_tech_id != user.id:
                raise HTTPException(status_code=409, detail="Chamado já atribuído a outro técnico")

            t.assigned_tech_id = user.id
            if t.status == "ABERTO":
                t.status = "ATRIBUIDO"
                t.assigned_at = datetime.utcnow()

            t.updated_at = datetime.utcnow()
            db.add(t)

            add_update(
                db, t.id, user.id, "ASSIGN",
                note="Assumido pelo admin",
                payload={"username": user.username, "tech_id": user.id}
            )
            if old_status != t.status:
                add_update(db, t.id, user.id, "STATUS_CHANGE", payload={"from": old_status, "to": t.status})

            db.commit()

    elif user.role == ROLE_TECH:
        if t.assigned_tech_id and t.assigned_tech_id != user.id:
            raise HTTPException(status_code=409, detail="Chamado já atribuído a outro técnico")

        t.assigned_tech_id = user.id
        if t.status == "ABERTO":
            t.status = "ATRIBUIDO"
            t.assigned_at = datetime.utcnow()

        t.updated_at = datetime.utcnow()
        db.add(t)

        add_update(
            db, t.id, user.id, "ASSIGN",
            note="Assumido pelo técnico",
            payload={"username": user.username, "tech_id": user.id}
        )
        if old_status != t.status:
            add_update(db, t.id, user.id, "STATUS_CHANGE", payload={"from": old_status, "to": t.status})

        db.commit()

    return TicketOut(
        id=t.id, store_id=t.store_id, store_name=store_name, status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
    )


# ---------- Start ----------
@router.post("/{ticket_id}/start", response_model=TicketOut)
def start_ticket(
    ticket_id: str,
    body: Optional[StatusRequest] = Body(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    if user.role not in (ROLE_TECH, ROLE_ADMIN):
        raise HTTPException(status_code=403, detail="Apenas técnico/admin")

    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    ensure_assigned_to_user(t, user)

    if t.status not in ("ATRIBUIDO", "PENDENTE"):
        raise HTTPException(status_code=409, detail="Status inválido para iniciar")

    old = t.status
    t.status = "EM_ATENDIMENTO"
    t.started_at = datetime.utcnow()
    t.updated_at = datetime.utcnow()

    db.add(t)

    note = (body.message if body else None)
    add_update(db, t.id, user.id, "STATUS_CHANGE", note=note, payload={"from": old, "to": "EM_ATENDIMENTO"})
    db.commit()

    store = db.query(Store).filter(Store.id == t.store_id).first()

    return TicketOut(
        id=t.id, store_id=t.store_id, store_name=(store.name if store else None), status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
    )


# ---------- Pend ----------
@router.post("/{ticket_id}/pend", response_model=TicketOut)
def pend_ticket(
    ticket_id: str,
    body: Optional[StatusRequest] = Body(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    if user.role not in (ROLE_TECH, ROLE_ADMIN):
        raise HTTPException(status_code=403, detail="Apenas técnico/admin")

    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    ensure_assigned_to_user(t, user)

    if t.status != "EM_ATENDIMENTO":
        raise HTTPException(status_code=409, detail="Só pode pendenciar em atendimento")

    old = t.status
    t.status = "PENDENTE"
    t.updated_at = datetime.utcnow()

    db.add(t)

    note = (body.message if body else None)
    add_update(db, t.id, user.id, "STATUS_CHANGE", note=note, payload={"from": old, "to": "PENDENTE"})
    db.commit()

    store = db.query(Store).filter(Store.id == t.store_id).first()

    return TicketOut(
        id=t.id, store_id=t.store_id, store_name=(store.name if store else None), status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
    )


# ---------- Comment ----------
@router.post("/{ticket_id}/comment")
def comment_ticket(
    ticket_id: str,
    body: CommentRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    ensure_can_view_ticket(db, user, t)

    add_update(db, t.id, user.id, "COMMENT", note=body.message)
    db.commit()

    return {"ok": True}


# ---------- Close with attachments ----------
@router.post("/{ticket_id}/close-with-attachments", response_model=TicketOut)
def close_ticket_with_attachments(
    ticket_id: str,
    parecer: str = Form(...),
    files: Optional[List[UploadFile]] = File(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.role not in (ROLE_TECH, ROLE_ADMIN):
        raise HTTPException(status_code=403, detail="Apenas técnico/admin")

    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    ensure_assigned_to_user(t, user)

    if t.status not in ("EM_ATENDIMENTO", "PENDENTE", "ATRIBUIDO"):
        raise HTTPException(status_code=409, detail="Status inválido para concluir")

    if db.query(TicketClosure).filter(TicketClosure.ticket_id == t.id).first():
        raise HTTPException(status_code=409, detail="Chamado já concluído")

    clean_parecer = parecer.strip()
    if len(clean_parecer) < 15:
        raise HTTPException(status_code=400, detail="Parecer deve ter pelo menos 15 caracteres")

    save_ticket_attachments(db=db, ticket=t, user=user, phase="FECHAMENTO", files=files)

    db.add(TicketClosure(
        ticket_id=t.id,
        resolution_text=clean_parecer,
        closed_by_user_id=user.id,
    ))

    old = t.status
    t.status = "CONCLUIDO"
    t.closed_at = datetime.utcnow()
    t.updated_at = datetime.utcnow()
    db.add(t)

    add_update(db, t.id, user.id, "CLOSE", note="Concluído com parecer", payload={"len": len(clean_parecer)})
    if old != "CONCLUIDO":
        add_update(db, t.id, user.id, "STATUS_CHANGE", payload={"from": old, "to": "CONCLUIDO"})

    db.commit()

    store = db.query(Store).filter(Store.id == t.store_id).first()
    return make_ticket_out(t, store.name if store else None)


# ---------- Close ----------
@router.post("/{ticket_id}/close", response_model=TicketOut)
def close_ticket(
    ticket_id: str,
    body: CloseRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user)
):
    if user.role not in (ROLE_TECH, ROLE_ADMIN):
        raise HTTPException(status_code=403, detail="Apenas técnico/admin")

    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    ensure_assigned_to_user(t, user)

    if t.status not in ("EM_ATENDIMENTO", "PENDENTE", "ATRIBUIDO"):
        raise HTTPException(status_code=409, detail="Status inválido para concluir")

    if db.query(TicketClosure).filter(TicketClosure.ticket_id == t.id).first():
        raise HTTPException(status_code=409, detail="Chamado já concluído")

    parecer = body.parecer.strip()

    db.add(TicketClosure(
        ticket_id=t.id,
        resolution_text=parecer,
        closed_by_user_id=user.id
    ))

    old = t.status
    t.status = "CONCLUIDO"
    t.closed_at = datetime.utcnow()
    t.updated_at = datetime.utcnow()

    db.add(t)

    add_update(db, t.id, user.id, "CLOSE", note="Concluído com parecer", payload={"len": len(parecer)})
    if old != "CONCLUIDO":
        add_update(db, t.id, user.id, "STATUS_CHANGE", payload={"from": old, "to": "CONCLUIDO"})

    db.commit()

    store = db.query(Store).filter(Store.id == t.store_id).first()

    return TicketOut(
        id=t.id, store_id=t.store_id, store_name=(store.name if store else None), status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
    )


# ---------- ✅ Opção 2: corrigir/editar parecer (TECH do chamado ou ADMIN) ----------
@router.patch("/{ticket_id}/closure", response_model=TicketOut)
def edit_ticket_closure(
    ticket_id: str,
    body: EditClosureRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    if user.role not in (ROLE_TECH, ROLE_ADMIN):
        raise HTTPException(status_code=403, detail="Apenas técnico/admin")

    t = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Chamado não encontrado")

    # precisa estar concluído
    if t.status != "CONCLUIDO":
        raise HTTPException(status_code=409, detail="Somente tickets CONCLUÍDOS podem ter parecer corrigido")

    closure = db.query(TicketClosure).filter(TicketClosure.ticket_id == t.id).first()
    if not closure:
        raise HTTPException(status_code=409, detail="Ticket não possui parecer registrado")

    # TECH só pode corrigir se for o técnico atribuído
    if user.role == ROLE_TECH:
        ensure_assigned_to_user(t, user)

    new_text = body.parecer.strip()
    old_text = (closure.resolution_text or "").strip()

    if not new_text:
        raise HTTPException(status_code=400, detail="Parecer não pode ser vazio")

    if new_text == old_text:
        raise HTTPException(status_code=400, detail="Parecer igual ao atual (sem alterações)")

    # atualiza
    closure.resolution_text = new_text
    t.updated_at = datetime.utcnow()

    # registra no histórico (reaproveita EDIT para não quebrar o frontend)
    add_update(
        db,
        t.id,
        user.id,
        "EDIT",
        note="Parecer corrigido",
        payload={
            "closure_edit": True,
            "before_len": len(old_text),
            "after_len": len(new_text),
        },
    )

    db.add(closure)
    db.add(t)
    db.commit()

    store = db.query(Store).filter(Store.id == t.store_id).first()

    return TicketOut(
        id=t.id, store_id=t.store_id, store_name=(store.name if store else None), status=t.status,
        problem=t.problem, type=t.type, priority=t.priority,
        requester_name=t.requester_name, local=t.local,
        assigned_tech_id=t.assigned_tech_id,
        opened_at=t.opened_at.isoformat() if t.opened_at else None,
        updated_at=t.updated_at.isoformat() if t.updated_at else None,
    )
